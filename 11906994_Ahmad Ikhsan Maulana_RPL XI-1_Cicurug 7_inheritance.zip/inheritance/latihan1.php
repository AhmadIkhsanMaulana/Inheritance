<?php 

	class Pakaian {
		public $warna,
			   $ukuran,
			   $bahan,
			   $harga,
			   $jmlpcs,
			   $jmlbuah;

		public function __construct($warna,$ukuran,$bahan,$harga,$jmlpcs, $jmlbuah) {
			$this->warna = $warna;
			$this->ukuran = $ukuran;
			$this->bahan = $bahan;
			$this->harga = $harga; 
			$this->jmlpcs = $jmlpcs;
			$this->jmlbuah= $jmlbuah; 

		}

		public function getbuy(){
			return "$this->ukuran,$this->bahan";
		}

		public function getinfoPakaian(){
			$str = " {$this->warna} {$this->getbuy()} {$this->harga}";
			return $str;
		}
		

	}

	class celana extends Pakaian {
		public function getinfoPakaian(){
			$str = "Celana : {$this->warna} {$this->getbuy()} (Rp.{$this->harga}) {$this->jmlpcs}/Pcs.";
			return $str;
		}
	}

	class baju extends Pakaian {
		public function getinfoPakaian(){
			$str = "Baju : {$this->warna} {$this->getbuy()} (Rp.{$this->harga}) {$this->jmlpcs}/buah.";
			return $str;
		}
	}


	$celana = new celana("Navy", "L", "Waterproof", 50000, 1, 0);
	$baju = new baju("Hijau","XL", "Katun", 75000, 2, 0);

	echo "Celana : ". $celana->getinfoPakaian();
	echo "<br>";
	echo "Baju   : ". $baju->getinfoPakaian();
	echo "<br>";

	


?>




 